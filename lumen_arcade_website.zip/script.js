const games = [
  {name:"Minecraft", icon:"⛏️", type:"Sandbox", url:"https://www.minecraft.net/"},
  {name:"Roblox", icon:"◈", type:"Online platform", url:"https://www.roblox.com/"},
  {name:"Fortnite", icon:"⚡", type:"Battle royale", url:"https://www.fortnite.com/"},
  {name:"FNaF", icon:"🐻", type:"Horror", url:"https://store.steampowered.com/app/319510/Five_Nights_at_Freddys/"},
  {name:"Rocket League", icon:"🚗", type:"Sports", url:"https://www.rocketleague.com/"},
  {name:"Among Us", icon:"👾", type:"Party", url:"https://www.innersloth.com/games/among-us/"},
  {name:"Terraria", icon:"🌲", type:"Adventure", url:"https://terraria.org/"},
  {name:"Stardew Valley", icon:"🌻", type:"Simulation", url:"https://www.stardewvalley.net/"}
];

const apps = [
  {name:"YouTube", icon:"▶️", type:"Video", url:"https://www.youtube.com/"},
  {name:"TikTok", icon:"♪", type:"Short videos", url:"https://www.tiktok.com/"},
  {name:"Spotify", icon:"🎵", type:"Music", url:"https://open.spotify.com/"},
  {name:"Discord", icon:"💬", type:"Community", url:"https://discord.com/"},
  {name:"Google", icon:"G", type:"Search", url:"https://www.google.com/"}
];

function render(items, elementId, countId) {
  const grid = document.getElementById(elementId);
  grid.innerHTML = items.map(item => `
    <a class="card" href="${item.url}" target="_blank" rel="noopener noreferrer">
      <div class="cover">${item.icon}</div>
      <div class="card-body">
        <h3>${item.name}</h3>
        <p>${item.type}</p>
      </div>
    </a>
  `).join("");
  document.getElementById(countId).textContent = `${items.length} available`;
}

function renderAll(filter = "") {
  const q = filter.toLowerCase().trim();
  const filteredGames = games.filter(x => (x.name + x.type).toLowerCase().includes(q));
  const filteredApps = apps.filter(x => (x.name + x.type).toLowerCase().includes(q));
  render(filteredGames, "gameGrid", "gameCount");
  render(filteredApps, "appGrid", "appCount");
}
document.getElementById("search").addEventListener("input", e => renderAll(e.target.value));
renderAll();
